class Node:

    def __init__(self, question, trueNode, falseNode):
        self.question = question
        self.trueBranch = trueNode
        self.falseBranch = falseNode